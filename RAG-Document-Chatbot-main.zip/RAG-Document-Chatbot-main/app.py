"""
RAG Document Chatbot
=====================
A beginner-friendly Retrieval-Augmented Generation chatbot built with:
- Streamlit (frontend)
- sentence-transformers (Hugging Face embeddings)
- FAISS (vector database)
- Groq API (LLM answer generation)

Users upload PDF/TXT documents, the app builds a local vector index,
and questions are answered ONLY from the retrieved document context.
"""

import os
import io
import re
import time
import numpy as np
import streamlit as st

# ---------------------------------------------------------------------------
# 1. CONFIGURABLE SETTINGS
#    Change these defaults any time. They can also be overridden from the
#    sidebar while the app is running.
# ---------------------------------------------------------------------------

# --> Change the Groq model used for answer generation here. <--
# Groq deprecated `llama-3.3-70b-versatile` (shutdown 08/16/2026).
# `openai/gpt-oss-120b` is the current recommended production model.
# `openai/gpt-oss-20b` is a smaller/faster alternative.
GROQ_MODEL = "openai/gpt-oss-120b"

# Hugging Face sentence-transformer model used to create embeddings.
EMBEDDING_MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"

# Chunking defaults (characters). 800-1000 chars with 100-200 overlap is a
# good starting point for most documents.
DEFAULT_CHUNK_SIZE = 900
DEFAULT_CHUNK_OVERLAP = 150

# Number of chunks retrieved per question.
DEFAULT_TOP_K = 4

# Maximum size (in MB) accepted per uploaded file, to keep the free-tier
# app responsive.
MAX_FILE_SIZE_MB = 25


# ---------------------------------------------------------------------------
# 2. GROQ API KEY HANDLING
#    Checks Streamlit secrets first, then falls back to an environment
#    variable. Never hardcode a key in this file.
# ---------------------------------------------------------------------------

def get_groq_api_key():
    """Return the Groq API key from st.secrets or the environment, or None."""
    try:
        if "GROQ_API_KEY" in st.secrets:
            return st.secrets["GROQ_API_KEY"]
    except Exception:
        pass
    return os.getenv("GROQ_API_KEY")


# ---------------------------------------------------------------------------
# 3. EMBEDDING MODEL (cached once per app process — this model has no
#    user-specific data, so a shared resource cache is safe and fast).
# ---------------------------------------------------------------------------

@st.cache_resource(show_spinner=False)
def load_embedding_model():
    from sentence_transformers import SentenceTransformer
    return SentenceTransformer(EMBEDDING_MODEL_NAME)


# ---------------------------------------------------------------------------
# 4. DOCUMENT TEXT EXTRACTION
# ---------------------------------------------------------------------------

def extract_pdf_pages(file_bytes, file_name):
    """
    Extract text from a PDF, page by page.
    Returns: (pages, error_message)
      pages -> list of dicts: {"page": int, "text": str}
      error_message -> string if something went wrong, else None
    """
    from pypdf import PdfReader
    from pypdf.errors import PdfReadError

    try:
        reader = PdfReader(io.BytesIO(file_bytes))
    except PdfReadError:
        return [], f"'{file_name}' could not be read. The file may be corrupted."
    except Exception as e:
        return [], f"'{file_name}' could not be opened ({e})."

    if reader.is_encrypted:
        try:
            # Try opening with an empty password (common for "restricted" PDFs)
            reader.decrypt("")
        except Exception:
            pass
        if reader.is_encrypted:
            return [], f"'{file_name}' is password-protected and cannot be read."

    pages = []
    for i, page in enumerate(reader.pages):
        try:
            text = page.extract_text() or ""
        except Exception:
            text = ""
        pages.append({"page": i + 1, "text": text.strip()})

    non_empty = [p for p in pages if p["text"]]
    if not non_empty:
        return [], (
            f"'{file_name}' has no extractable text. It may be a scanned "
            f"(image-only) PDF. Ordinary PDF libraries cannot read scanned "
            f"pages — that would require OCR, which this basic app does not "
            f"include."
        )
    return pages, None


def extract_txt(file_bytes, file_name):
    """Decode a TXT file. Returns (text, error_message)."""
    try:
        text = file_bytes.decode("utf-8", errors="ignore").strip()
    except Exception as e:
        return "", f"'{file_name}' could not be decoded as text ({e})."
    if not text:
        return "", f"'{file_name}' is empty."
    return text, None


# ---------------------------------------------------------------------------
# 5. CHUNKING
# ---------------------------------------------------------------------------

def chunk_text(text, chunk_size, chunk_overlap):
    """
    Split text into overlapping chunks of roughly `chunk_size` characters,
    breaking on whitespace where possible so words aren't cut in half.
    """
    text = re.sub(r"\s+", " ", text).strip()
    if not text:
        return []

    chunks = []
    start = 0
    length = len(text)
    step = max(chunk_size - chunk_overlap, 1)

    while start < length:
        end = min(start + chunk_size, length)
        # try to end on a space instead of mid-word
        if end < length:
            last_space = text.rfind(" ", start, end)
            if last_space > start:
                end = last_space
        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)
        if end >= length:
            break
        start += step

    return chunks


# ---------------------------------------------------------------------------
# 6. BUILD THE VECTOR DATABASE (FAISS)
# ---------------------------------------------------------------------------

def build_vector_index(all_chunks, embedder):
    """
    all_chunks: list of dicts with "text" key (and metadata)
    Returns a FAISS index built from normalized embeddings (cosine similarity
    via inner product).
    """
    import faiss

    texts = [c["text"] for c in all_chunks]
    embeddings = embedder.encode(
        texts, show_progress_bar=False, convert_to_numpy=True
    ).astype("float32")

    faiss.normalize_L2(embeddings)
    dim = embeddings.shape[1]
    index = faiss.IndexFlatIP(dim)
    index.add(embeddings)
    return index


def retrieve_chunks(query, index, all_chunks, embedder, top_k):
    """Return the top_k most relevant chunk dicts for a query."""
    import faiss

    query_vec = embedder.encode([query], convert_to_numpy=True).astype("float32")
    faiss.normalize_L2(query_vec)
    scores, indices = index.search(query_vec, min(top_k, len(all_chunks)))

    results = []
    for score, idx in zip(scores[0], indices[0]):
        if idx == -1:
            continue
        chunk = dict(all_chunks[idx])
        chunk["score"] = float(score)
        results.append(chunk)
    return results


# ---------------------------------------------------------------------------
# 7. RAG PROMPT + GROQ CALL
# ---------------------------------------------------------------------------

def build_prompt(context_chunks, history, question):
    context_text = "\n\n".join(
        f"[Source: {c['source']}, Page {c['page']}]\n{c['text']}"
        for c in context_chunks
    )
    history_text = "\n".join(
        f"{turn['role'].capitalize()}: {turn['content']}" for turn in history[-6:]
    ) or "(no previous messages)"

    prompt = f"""Role:
You are a document question-answering assistant. You answer questions using
ONLY the retrieved context below, which comes from documents the user
uploaded.

Instructions:
- Answer strictly from the Retrieved Context. Do not use outside knowledge.
- Do not invent, guess, or assume facts that are not in the context.
- If the answer is not present in the context, respond exactly with:
  "I could not find this information in the uploaded documents."
- Use the Conversation History only to understand follow-up questions
  (e.g. "what about the second one?"). Do not treat history as a source
  of facts about the documents.
- Keep the answer clear, complete, and directly responsive to the question.
- Mention the source document(s) when relevant, but never claim a source
  was used unless it appears in the Retrieved Context below.

Retrieved Context:
{context_text}

Conversation History:
{history_text}

User Question:
{question}

Answer:"""
    return prompt


def call_groq(prompt, api_key, model):
    """Call the Groq API. Returns (answer_text, error_message)."""
    from groq import Groq

    try:
        client = Groq(api_key=api_key)
        response = client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.2,
            max_tokens=1024,
        )
        return response.choices[0].message.content, None
    except Exception as e:
        msg = str(e).lower()
        if "401" in msg or "authentic" in msg or "invalid api key" in msg:
            return None, "Your Groq API key appears to be invalid. Please check it in Settings → Secrets."
        if "404" in msg or "does not exist" in msg or "decommissioned" in msg:
            return None, f"The model '{model}' is unavailable or deprecated. Update GROQ_MODEL in app.py to a current model."
        if "429" in msg or "rate limit" in msg:
            return None, "Groq's rate limit was reached. Please wait a moment and try again."
        if "timeout" in msg:
            return None, "The request to Groq timed out. Please try again."
        if "connection" in msg or "network" in msg:
            return None, "Could not reach the Groq API. Please check your internet connection."
        return None, f"An unexpected error occurred while contacting Groq: {e}"


# ---------------------------------------------------------------------------
# 8. SESSION STATE INITIALIZATION
#    Every value below is scoped to the current user's browser session —
#    no data is shared between different users of the deployed app.
# ---------------------------------------------------------------------------

def init_session_state():
    defaults = {
        "chat_history": [],       # list of {"role", "content", "sources"}
        "all_chunks": [],         # list of {"text", "source", "page", "chunk_id"}
        "faiss_index": None,
        "kb_ready": False,
        "processed_file_names": [],
        "chunk_size": DEFAULT_CHUNK_SIZE,
        "chunk_overlap": DEFAULT_CHUNK_OVERLAP,
        "top_k": DEFAULT_TOP_K,
        "groq_model": GROQ_MODEL,
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


def reset_knowledge_base():
    st.session_state.all_chunks = []
    st.session_state.faiss_index = None
    st.session_state.kb_ready = False
    st.session_state.processed_file_names = []


def clear_chat():
    st.session_state.chat_history = []


# ---------------------------------------------------------------------------
# 9. DOCUMENT PROCESSING PIPELINE
# ---------------------------------------------------------------------------

def process_uploaded_files(uploaded_files, embedder, chunk_size, chunk_overlap):
    all_chunks = []
    errors = []
    processed_names = []

    for file in uploaded_files:
        size_mb = len(file.getvalue()) / (1024 * 1024)
        if size_mb > MAX_FILE_SIZE_MB:
            errors.append(f"'{file.name}' is larger than {MAX_FILE_SIZE_MB} MB and was skipped.")
            continue

        ext = file.name.lower().split(".")[-1]
        file_bytes = file.getvalue()

        if ext == "pdf":
            pages, error = extract_pdf_pages(file_bytes, file.name)
            if error:
                errors.append(error)
                continue
            chunk_id = 0
            for page in pages:
                for chunk in chunk_text(page["text"], chunk_size, chunk_overlap):
                    chunk_id += 1
                    all_chunks.append({
                        "text": chunk,
                        "source": file.name,
                        "page": page["page"],
                        "chunk_id": chunk_id,
                    })

        elif ext == "txt":
            text, error = extract_txt(file_bytes, file.name)
            if error:
                errors.append(error)
                continue
            chunk_id = 0
            for chunk in chunk_text(text, chunk_size, chunk_overlap):
                chunk_id += 1
                all_chunks.append({
                    "text": chunk,
                    "source": file.name,
                    "page": "-",
                    "chunk_id": chunk_id,
                })
        else:
            errors.append(f"'{file.name}' is not a supported file type (only PDF and TXT are supported).")
            continue

        processed_names.append(file.name)

    return all_chunks, processed_names, errors


# ---------------------------------------------------------------------------
# 10. THEME — glowing dark-blue UI
#     Design tokens:
#       bg-deep        #060912   (near-black deep-blue shell)
#       bg-panel       rgba(13,18,32,0.70)  (glass panels)
#       accent-blue    #3B82F6   (primary glow — buttons, focus, links)
#       accent-cyan    #22D3EE   (secondary glow — highlights, mono data)
#       accent-deep    #1E3A8A   (shadow depth for the glow)
#       text-primary   #E7ECFA
#       text-muted     #8891AC
#     Display face: Space Grotesk (headings) · Body: Inter · Data: JetBrains Mono
#     NOTE: .streamlit/config.toml sets base="dark" + primaryColor so native
#     widgets (sliders, the "Browse files" button, focus rings, the top
#     header bar) inherit the right colors instead of Streamlit's light
#     defaults — this CSS then layers the glow/gradient/font details on top.
# ---------------------------------------------------------------------------

CUSTOM_THEME_CSS = """
<style>
@import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;700&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap');

:root {
    --bg-deep: #060912;
    --bg-panel: rgba(13, 18, 32, 0.70);
    --bg-panel-solid: #0D1220;
    --border-glow: rgba(59, 130, 246, 0.38);
    --accent-blue: #3B82F6;
    --accent-cyan: #22D3EE;
    --accent-deep: #1E3A8A;
    --text-primary: #E7ECFA;
    --text-muted: #8891AC;
}

/* ---- App shell (covers current + older Streamlit container class names) ---- */
.stApp, [data-testid="stAppViewContainer"], [data-testid="stMain"] {
    background:
        radial-gradient(ellipse 900px 500px at 15% -10%, rgba(59, 130, 246, 0.18), transparent 60%),
        radial-gradient(ellipse 700px 500px at 100% 10%, rgba(34, 211, 238, 0.12), transparent 55%),
        var(--bg-deep) !important;
    color: var(--text-primary);
    font-family: 'Inter', sans-serif;
}
[data-testid="stHeader"], [data-testid="stToolbar"] {
    background: var(--bg-deep) !important;
}
html, body, [class*="css"] { font-family: 'Inter', sans-serif; }
h1, h2, h3, h4 { font-family: 'Space Grotesk', sans-serif !important; letter-spacing: -0.01em; }

/* ---- Hero header ---- */
.hero-wrap {
    position: relative;
    padding: 1.6rem 0 1.1rem 0;
    margin-bottom: 0.6rem;
    overflow: visible;
}
.hero-aura {
    position: absolute;
    top: -60px; left: -40px;
    width: 340px; height: 220px;
    background: radial-gradient(circle, rgba(59,130,246,0.40), rgba(34,211,238,0.16) 55%, transparent 75%);
    filter: blur(38px);
    z-index: 0;
    animation: auraBreathe 6s ease-in-out infinite;
}
@keyframes auraBreathe {
    0%, 100% { opacity: 0.65; transform: scale(1); }
    50% { opacity: 1; transform: scale(1.12); }
}
.hero-title {
    position: relative;
    z-index: 1;
    font-family: 'Space Grotesk', sans-serif;
    font-weight: 700;
    font-size: 2.4rem;
    margin: 0;
    background: linear-gradient(90deg, #F0F6FF 0%, var(--accent-blue) 55%, var(--accent-cyan) 100%);
    -webkit-background-clip: text;
    background-clip: text;
    color: transparent;
    text-shadow: 0 0 34px rgba(59, 130, 246, 0.4);
}
.hero-caption {
    position: relative;
    z-index: 1;
    color: var(--text-muted);
    font-size: 0.95rem;
    max-width: 640px;
    margin-top: 0.35rem;
}

/* ---- Sidebar glass panel ---- */
[data-testid="stSidebar"] {
    background: linear-gradient(180deg, rgba(13,18,32,0.95), rgba(6,9,18,0.98)) !important;
    border-right: 1px solid rgba(59, 130, 246, 0.16);
}
[data-testid="stSidebar"] h2, [data-testid="stSidebar"] h3 {
    color: var(--text-primary);
}

/* ---- Buttons (incl. the file-uploader "Browse files" button) ---- */
.stButton > button, [data-testid="stFormSubmitButton"] button,
[data-testid="stFileUploaderDropzone"] button {
    background: linear-gradient(135deg, rgba(59,130,246,0.28), rgba(34,211,238,0.18)) !important;
    border: 1px solid var(--border-glow) !important;
    color: var(--text-primary) !important;
    border-radius: 10px;
    font-weight: 500;
    transition: box-shadow 0.2s ease, transform 0.15s ease, border-color 0.2s ease;
}
.stButton > button:hover, [data-testid="stFileUploaderDropzone"] button:hover {
    border-color: var(--accent-cyan) !important;
    box-shadow: 0 0 18px rgba(34, 211, 238, 0.4);
    transform: translateY(-1px);
}

/* ---- Chat messages ---- */
[data-testid="stChatMessage"] {
    background: var(--bg-panel);
    border: 1px solid rgba(59, 130, 246, 0.2);
    border-radius: 14px;
    box-shadow: 0 0 22px rgba(59, 130, 246, 0.1);
    padding: 0.35rem 0.4rem;
    margin-bottom: 0.6rem;
}

/* ---- Chat input ---- */
[data-testid="stChatInput"] {
    background: var(--bg-panel-solid) !important;
    border: 1px solid var(--border-glow);
    border-radius: 12px;
    box-shadow: 0 0 24px rgba(59, 130, 246, 0.16);
}
[data-testid="stChatInput"] textarea { color: var(--text-primary) !important; }

/* ---- Expanders (Sources) ---- */
[data-testid="stExpander"] {
    background: rgba(9, 12, 22, 0.65) !important;
    border: 1px solid rgba(34, 211, 238, 0.22);
    border-radius: 10px;
}
[data-testid="stExpander"] * { font-family: 'JetBrains Mono', monospace !important; font-size: 0.82rem; }

/* ---- File uploader ---- */
[data-testid="stFileUploaderDropzone"] {
    background: rgba(13, 18, 32, 0.55) !important;
    border: 1px dashed var(--border-glow) !important;
    border-radius: 12px;
}

/* ---- Status / alerts ---- */
[data-testid="stStatusWidget"], .stAlert {
    border-radius: 10px;
    border: 1px solid rgba(59, 130, 246, 0.22);
}

/* ---- Sliders (thumb + filled track glow; color itself follows primaryColor) ---- */
div[data-baseweb="slider"] [role="slider"] {
    box-shadow: 0 0 10px rgba(34, 211, 238, 0.7) !important;
}

/* ---- Corner signature (bottom-left, out of Streamlit Cloud's own toolbar area) ---- */
.made-by-badge {
    position: fixed;
    left: 14px;
    bottom: 10px;
    z-index: 999;
    font-family: 'JetBrains Mono', monospace;
    font-size: 0.72rem;
    color: var(--text-muted);
    background: rgba(6, 9, 18, 0.6);
    border: 1px solid rgba(59, 130, 246, 0.28);
    padding: 4px 10px;
    border-radius: 999px;
    text-shadow: 0 0 12px rgba(34, 211, 238, 0.3);
    pointer-events: none;
    backdrop-filter: blur(6px);
}

@media (prefers-reduced-motion: reduce) {
    .hero-aura { animation: none; }
}
</style>
"""


def render_theme_and_hero():
    st.markdown(CUSTOM_THEME_CSS, unsafe_allow_html=True)
    st.markdown(
        """
        <div class="hero-wrap">
            <div class="hero-aura"></div>
            <h1 class="hero-title">📄 RAG Document Chatbot</h1>
            <p class="hero-caption">
                Upload PDF or TXT documents, build a knowledge base, and ask questions.
                Answers come only from the documents you upload — the assistant will
                tell you when something isn't in your files.
            </p>
        </div>
        <div class="made-by-badge">Made by Muhammad Haseeb Subhani</div>
        """,
        unsafe_allow_html=True,
    )


# ---------------------------------------------------------------------------
# 11. STREAMLIT UI
# ---------------------------------------------------------------------------

st.set_page_config(page_title="RAG Document Chatbot", page_icon="📄", layout="wide")
init_session_state()
render_theme_and_hero()

# ---- Sidebar: settings + upload -------------------------------------------
with st.sidebar:
    st.header("⚙️ Settings")

    st.session_state.groq_model = st.text_input(
        "Groq model", value=st.session_state.groq_model,
        help="The Groq model ID used to generate answers.",
    )
    st.session_state.chunk_size = st.slider(
        "Chunk size (characters)", 400, 1500, st.session_state.chunk_size, step=50,
    )
    st.session_state.chunk_overlap = st.slider(
        "Chunk overlap (characters)", 0, 400, st.session_state.chunk_overlap, step=25,
    )
    st.session_state.top_k = st.slider(
        "Chunks retrieved per question", 1, 10, st.session_state.top_k,
    )

    st.divider()
    st.header("📁 Documents")

    uploaded_files = st.file_uploader(
        "Upload PDF or TXT files", type=["pdf", "txt"], accept_multiple_files=True,
    )

    process_col, reset_col = st.columns(2)
    process_clicked = process_col.button("Process Documents", use_container_width=True)
    reset_clicked = reset_col.button("Reset Knowledge Base", use_container_width=True)

    if reset_clicked:
        reset_knowledge_base()
        st.success("Knowledge base cleared.")

    if process_clicked:
        if not uploaded_files:
            st.warning("Please upload at least one PDF or TXT file first.")
        else:
            with st.spinner("Loading embedding model (first run may take a minute)..."):
                embedder = load_embedding_model()

            with st.status("Processing documents...", expanded=True) as status:
                st.write("Extracting text and splitting into chunks...")
                all_chunks, processed_names, errors = process_uploaded_files(
                    uploaded_files, embedder,
                    st.session_state.chunk_size, st.session_state.chunk_overlap,
                )

                for err in errors:
                    st.warning(err)

                if not all_chunks:
                    status.update(label="No usable text found.", state="error")
                    st.error("No extractable text was found in the uploaded file(s).")
                else:
                    st.write(f"Created {len(all_chunks)} chunks. Building embeddings and vector index...")
                    try:
                        index = build_vector_index(all_chunks, embedder)
                    except Exception as e:
                        status.update(label="Failed to build vector index.", state="error")
                        st.error(f"Could not build the vector database: {e}")
                    else:
                        st.session_state.all_chunks = all_chunks
                        st.session_state.faiss_index = index
                        st.session_state.kb_ready = True
                        st.session_state.processed_file_names = processed_names
                        status.update(label="Knowledge base ready!", state="complete")
                        st.success(f"Processed {len(processed_names)} document(s) into {len(all_chunks)} chunks.")

    if st.session_state.processed_file_names:
        st.divider()
        st.subheader("Indexed documents")
        for name in st.session_state.processed_file_names:
            st.write(f"• {name}")

    st.divider()
    if st.button("🗑️ Clear Chat", use_container_width=True):
        clear_chat()
        st.rerun()

# ---- Main area: chat -------------------------------------------------------
api_key = get_groq_api_key()
if not api_key:
    st.error(
        "No Groq API key found. Add it to Streamlit secrets as GROQ_API_KEY "
        "(App settings → Secrets) or set it as an environment variable."
    )

if not st.session_state.kb_ready:
    st.info("Upload documents and click **Process Documents** in the sidebar to get started.")

# Render existing chat history
for turn in st.session_state.chat_history:
    with st.chat_message(turn["role"]):
        st.markdown(turn["content"])
        if turn.get("sources"):
            with st.expander("Sources"):
                for s in turn["sources"]:
                    st.markdown(f"- **{s['source']}** — Page {s['page']}")
                    st.caption(s["text"][:300] + ("..." if len(s["text"]) > 300 else ""))

# Chat input
question = st.chat_input("Ask a question about your documents...")

if question:
    if not api_key:
        st.error("Cannot generate an answer: no Groq API key is configured.")
    elif not st.session_state.kb_ready:
        st.warning("Please process your documents before asking a question.")
    elif not question.strip():
        st.warning("Please enter a non-empty question.")
    else:
        st.session_state.chat_history.append({"role": "user", "content": question, "sources": None})
        with st.chat_message("user"):
            st.markdown(question)

        with st.chat_message("assistant"):
            with st.spinner("Searching documents and generating an answer..."):
                embedder = load_embedding_model()
                retrieved = retrieve_chunks(
                    question, st.session_state.faiss_index, st.session_state.all_chunks,
                    embedder, st.session_state.top_k,
                )
                prompt = build_prompt(retrieved, st.session_state.chat_history, question)
                answer, error = call_groq(prompt, api_key, st.session_state.groq_model)

            if error:
                st.error(error)
                answer_text = None
            else:
                st.markdown(answer)
                # de-duplicate sources for display
                seen = set()
                unique_sources = []
                for c in retrieved:
                    key = (c["source"], c["page"])
                    if key not in seen:
                        seen.add(key)
                        unique_sources.append(c)
                if unique_sources:
                    with st.expander("Sources"):
                        for s in unique_sources:
                            st.markdown(f"- **{s['source']}** — Page {s['page']}")
                            st.caption(s["text"][:300] + ("..." if len(s["text"]) > 300 else ""))
                answer_text = answer

        if answer_text:
            st.session_state.chat_history.append({
                "role": "assistant",
                "content": answer_text,
                "sources": unique_sources if unique_sources else None,
            })
